Mapping Prototype #4
