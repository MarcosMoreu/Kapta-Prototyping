$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/handler/Edit.Poly.js',
   success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/handler/Edit.SimpleShape.js',
   success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/handler/Edit.Marker.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/draw/handler/Draw.Feature.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/draw/handler/Draw.Polyline.js',
   // success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/draw/handler/Draw.Polygon.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/draw/handler/Draw.Marker.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/ext/TouchEvents.js',
   // success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/ext/GeometryUtil.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/ext/LineUtil.Intersect.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/ext/Polyline.Intersect.js',
   // success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/ext/Polygon.Intersect.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/Control.Draw.js'
}),

$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/Tooltip.js',
   // success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/Toolbar.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/draw/DrawToolbar.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/EditToolbar.js',
   // success: console.log('d3 fetched')
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/handler/EditToolbar.Edit.js'
}),
$.getScript({
  cache:true,
  url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/handler/EditToolbar.Delete.js'
})



// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/leaflet.Permalink-master/leaflet.permalink.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/emojionearea-master/dist/emojionearea.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/Leaflet.draw.js',
//    // success: console.log('d3 fetched')
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/Leaflet.Draw.Event.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/Leaflet.EasyButton-master/src/easy-button.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/localForage-master/dist/localforage.js',
//    // success: console.log('d3 fetched')
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/leaflet-offline-master/dist/leaflet-offline.min.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/Leaflet.markercluster-1.4.1/dist/leaflet.markercluster-src.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/Leaflet.Deflate-master/dist/L.Deflate.js',
//    // success: console.log('d3 fetched')
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/L.Control.Rose-master/dist/L.Control.Rose.js'
// }),
// $.getScript({
//   cache:true,
//   url:'scripts/lib/leaflet/plugins/Leaflet.draw-1.0.4/src/edit/handler/Edit.Poly.js'
// }),
//
//
