// console.log('url', url)
// var urlContainsHashCustomised = url.includes('#Customised')

//to return to the map
document.getElementById('customIconsMap').onclick = function(e){
  document.getElementById('customIconsMap').style.display = 'none';
  document.getElementById('customIconsCancel').style.display = 'none';
  // document.getElementById('showProjects').style.display = 'none';


  document.getElementById("map").style.height = "100%";
  document.getElementById("Cancel").style.display = "initial";
  document.getElementById("sapelliProjects").style.display = "initial";
  document.getElementById('emoji').style.display = 'initial';
  // document.getElementById('showAreaHa').style.display = 'none';
  document.getElementById('showAreaAcres').style.display = 'initial';
  document.getElementById('share-download').style.display = 'initial';

}

document.getElementById('showProjects').onclick = function(e){
  document.getElementById("customIconsCancel").style.display = "none";
  document.getElementById("showProjects").style.display = "none";
  newProjectButton.style.display = 'initial';

}

var projectsCreated = false
//excites Logo in the map: to open the sapelli project
document.getElementById('sapelliProjects').onclick = function(e){
  document.getElementById("map").style.height = "0px";

  document.getElementById("Cancel").style.display = "none";
  document.getElementById("sapelliProjects").style.display = "none";
  document.getElementById('emoji').style.display = 'none';
  // document.getElementById('showAreaHa').style.display = 'none';
  document.getElementById('showAreaAcres').style.display = 'none';
  document.getElementById('share-download').style.display = 'none';
  document.body.style.background = 'black';
  // document.getElementById('customIconsMap').style.display = 'none';
  document.getElementById('customIconsMap').style.display = 'initial';

  if(projectsCreated == false){
        newProjectButton = document.createElement("BUTTON");
        document.body.appendChild(newProjectButton);
        newProjectButton.style.backgroundColor = 'white'
        newProjectButton.style.width = '80px'
        newProjectButton.style.height = '80px'
        newProjectButton.style.borderColor = 'black'
        newProjectButton.style.marginBottom = '200px'
        newProjectButton.style.marginLeft = '20px'
        newProjectButton.innerHTML = '<img src="images/logoNigeria.png" style="width:50px ; height:50px; border: 0px solid white" />';

        //to show the icons of the project selected
        newProjectButton.onclick = function(){
          newProjectButton.style.display = 'none';
          document.getElementById('customIconsCancel').style.display = 'initial';
          // document.getElementById('customIconsMap').style.display = 'none';
          function preloadImage(){
            $(['images/csaNigeria/Crops/Cereals.png',
            'images/csaNigeria/Crops/Vegetables.png',
            'images/csaNigeria/Crops/Fruits.png',
            'images/csaNigeria/Crops/Tubers.png',
            "images/csaNigeria/Crops/pulses.png",
            "images/csaNigeria/Crops/cashCrop.png",
            "images/csaNigeria/Crops/nuts.png",


            ]).preload();
          }
          gridCreateGrid()
        }
  }else{
    newProjectButton.style.display = 'initial';
  }
  projectsCreated = true
  return projectsCreated
}

var gridCreateGrid = function(){
  icon1 = document.createElement("BUTTON");
  document.body.appendChild(icon1);
  icon1.className = 'buttonsSapelli'
  icon1.innerHTML = '<img src="images/csaNigeria/Crops/Cereals.png" style="width:50px ; height:50px; border: 0px solid white" />';

  var icon2 = document.createElement("BUTTON");
  document.body.appendChild(icon2);
  icon2.innerHTML = '<img src="images/csaNigeria/Crops/Vegetables.png" style="width:50px ; height:50px; border: 0px solid white" />';
  icon2.className = 'buttonsSapelli'

  var icon3 = document.createElement("BUTTON");
  document.body.appendChild(icon3);
  icon3.className = 'buttonsSapelli'
  icon3.innerHTML = '<img src="images/csaNigeria/Crops/Fruits.png" style="width:50px ; height:50px; border: 0px solid white" />';

  var icon4 = document.createElement("BUTTON");
  document.body.appendChild(icon4);
  icon4.innerHTML = '<img src="images/csaNigeria/Crops/Tubers.png" style="width:50px ; height:50px; border: 0px solid white" />';
  icon4.className = 'buttonsSapelli'

  var icon5 = document.createElement("BUTTON");
  document.body.appendChild(icon5);
  icon5.className = 'buttonsSapelli'
  icon5.innerHTML = '<img src="images/csaNigeria/Crops/pulses.png" style="width:50px ; height:50px; border: 0px solid white" />';

  var icon6 = document.createElement("BUTTON");
  document.body.appendChild(icon6);
  icon6.innerHTML = '<img src="images/csaNigeria/Crops/cashCrop.png" style="width:50px ; height:50px; border: 0px solid white" />';
  icon6.className = 'buttonsSapelli'

  var icon7 = document.createElement("BUTTON");
  document.body.appendChild(icon7);
  icon7.innerHTML = '<img src="images/csaNigeria/Crops/nuts.png" style="width:50px ; height:50px; border: 0px solid white" />';
  icon7.className = 'buttonsSapelli'

  ///////////////////
  icon1.onclick = function(){
    icon1.style.display = 'none'
    icon2.style.display = 'none'
    icon3.style.display = 'none'
    icon4.style.display = 'none'
    icon5.style.display = 'none'
    icon6.style.display = 'none'
    icon7.style.display = 'none'


    var icon8 = document.createElement("BUTTON");
    document.body.appendChild(icon1);
    icon8.className = 'buttonsSapelli'
    icon8.innerHTML = '<img src="images/csaNigeria/Crops/Maize.png" style="width:50px ; height:50px; border: 0px solid white" />';

    var icon9 = document.createElement("BUTTON");
    document.body.appendChild(icon2);
    icon9.innerHTML = '<img src="images/csaNigeria/Crops/rice.png" style="width:50px ; height:50px; border: 0px solid white" />';
    icon9.className = 'buttonsSapelli'

    // var icon10 = document.createElement("BUTTON");
    // document.body.appendChild(icon3);
    // icon10.className = 'buttonsSapelli'
    // icon10.innerHTML = '<img src="images/csaNigeria/Crops/Fruits.png" style="width:50px ; height:50px; border: 0px solid white" />';
    //
    // var icon11 = document.createElement("BUTTON");
    // document.body.appendChild(icon4);
    // icon11.innerHTML = '<img src="images/csaNigeria/Crops/Tubers.png" style="width:50px ; height:50px; border: 0px solid white" />';
    // icon11.className = 'buttonsSapelli'
    //
    // var icon12 = document.createElement("BUTTON");
    // document.body.appendChild(icon5);
    // icon12.className = 'buttonsSapelli'
    // icon12.innerHTML = '<img src="images/csaNigeria/Crops/pulses.png" style="width:50px ; height:50px; border: 0px solid white" />';
    //
    // var icon13 = document.createElement("BUTTON");
    // document.body.appendChild(icon6);
    // icon13.innerHTML = '<img src="images/csaNigeria/Crops/cashCrop.png" style="width:50px ; height:50px; border: 0px solid white" />';
    // icon13.className = 'buttonsSapelli'
    //
    // var icon14 = document.createElement("BUTTON");
    // document.body.appendChild(icon7);
    // icon14.innerHTML = '<img src="images/csaNigeria/Crops/nuts.png" style="width:50px ; height:50px; border: 0px solid white" />';
    // icon14.className = 'buttonsSapelli'

    icon8.style.display = 'initial'
    icon9.style.display = 'initial'
    // icon10.style.display = 'initial'
    // icon11.style.display = 'initial'
    // icon12.style.display = 'initial'
    // icon13.style.display = 'initial'
    // icon14.style.display = 'initial'
  }

  document.getElementById('customIconsCancel').onclick = function(e){
    icon1.style.display = 'initial'
    icon2.style.display = 'initial'
    icon3.style.display = 'initial'
    icon4.style.display = 'initial'
    icon5.style.display = 'initial'
    icon6.style.display = 'initial'
    icon7.style.display = 'initial'
  }

}

//to delete attributes and start again


//to go back to main screen where projects are shown




// document.getElementById('nigeriaProject').onclick = function(e){
//   // document.getElementById("map").style.height = "0px";
//   //
//   // document.getElementById("Cancel").style.display = "none";
//   // document.getElementById("CustomIcons").style.display = "none";
//   // document.getElementById('emoji').style.display = 'none';
//   // // document.getElementById('showAreaHa').style.display = 'none';
//   // document.getElementById('showAreaAcres').style.display = 'none';
//   // document.getElementById('share-download').style.display = 'none';
//   document.getElementById('showProjects').style.display = 'initial';
//   document.getElementById('customIconsMap').style.display = 'initial';
//   document.getElementById('customIconsCancel').style.display = 'initial';
// }
