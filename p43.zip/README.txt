Prototype#3
