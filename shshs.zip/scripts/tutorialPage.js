var dropDownOpen = false;
var isOnline = navigator.onLine

document.getElementById('startMapping').onclick = function(e){
   setTimeout(function(){
     location.href='../index.html';
   },100)
  }
document.getElementById('dropDown').onclick = function(e){

    if(dropDownOpen == false){
      document.getElementById('infoButton').style.display = "initial";
      document.getElementById('iconsButton').style.display = "initial";

      if(isOnline == true){
        document.getElementById('cutomiseButton').style.display = "initial";
        document.getElementById('iconsButton').style.display = "initial";

      }
      document.getElementById('dropDown').style.backgroundColor = 'grey';
      document.getElementById('imageDropDown').src = '../images/burgerBlack.png';
      dropDownOpen = true
    }else{
      document.getElementById('infoButton').style.display = "none";
      document.getElementById('cutomiseButton').style.display = "none";
      document.getElementById('iconsButton').style.display = "none";
      document.getElementById('dropDown').style.backgroundColor = 'black';
      document.getElementById('imageDropDown').src = '../images/burger.png';

      dropDownOpen = false
    }

    return dropDownOpen
  }

  document.getElementById('cutomiseButton').onclick = function(e){
     setTimeout(function(){
       document.getElementById("infoGoBackButton").style.display = "initial";
       document.getElementById("cognitoForm").style.display = "initial";
       document.body.style.overflow = 'visible';
       document.getElementById('dropDown').style.display = "none";
       document.getElementById('cutomiseButton').style.display = "none";
      document.getElementById('infoButton').style.display = "none";
      document.getElementById("iconsButton").style.display = "none";
      document.getElementById('cutomiseButton').style.display = "none";
      document.getElementById("youtube").style.display = "none";
      document.getElementById("startMapping").style.display = "none";
      document.getElementById("spanish").style.display = "none";
      document.getElementById("english").style.display = "none";
      document.getElementById("french").style.display = "none";
      document.getElementById("portuguese").style.display = "none";
      document.getElementById("swahili").style.display = "none";
      document.getElementById("juhoansi").style.display = "none";
      document.getElementById("other1").style.display = "none";
      document.getElementById("textEnglish").style.display = "none";
      document.getElementById("textSpanish").style.display = "none";
      document.getElementById("textFrench").style.display = "none";
      document.getElementById("textPortuguese").style.display = "none";
      document.getElementById("textSwahili").style.display = "none";
      document.getElementById("textJuhoansi").style.display = "none";

     },100)
    }

document.getElementById('infoButton').onclick = function(e){
   setTimeout(function(){
     document.getElementById("infoGoBackButton").style.display = "initial";
     document.getElementById("infoCont").style.display = "initial";

     document.getElementById('dropDown').style.display = "none";
     document.getElementById('cutomiseButton').style.display = "none";
    document.getElementById("youtube").style.display = "none";
    document.getElementById("startMapping").style.display = "none";
    document.getElementById("infoButton").style.display = "none";
    document.getElementById("iconsButton").style.display = "none";

    document.getElementById("spanish").style.display = "none";
    document.getElementById("english").style.display = "none";
    document.getElementById("french").style.display = "none";
    document.getElementById("portuguese").style.display = "none";
    document.getElementById("swahili").style.display = "none";
    document.getElementById("juhoansi").style.display = "none";
    document.getElementById("other1").style.display = "none";
    document.getElementById("textEnglish").style.display = "none";
    document.getElementById("textSpanish").style.display = "none";
    document.getElementById("textFrench").style.display = "none";
    document.getElementById("textPortuguese").style.display = "none";
    document.getElementById("textSwahili").style.display = "none";
    document.getElementById("textJuhoansi").style.display = "none";

   },100)
  }
document.getElementById('iconsButton').onclick = function(e){
   setTimeout(function(){
     document.getElementById("infoGoBackButton").style.display = "initial";
     document.getElementById("iconsCont").style.display = "initial";

     document.getElementById('dropDown').style.display = "none";
     document.getElementById('cutomiseButton').style.display = "none";
    document.getElementById("youtube").style.display = "none";
    document.getElementById("startMapping").style.display = "none";
    document.getElementById("infoButton").style.display = "none";
    document.getElementById("iconsButton").style.display = "none";

    document.getElementById("spanish").style.display = "none";
    document.getElementById("english").style.display = "none";
    document.getElementById("french").style.display = "none";
    document.getElementById("portuguese").style.display = "none";
    document.getElementById("swahili").style.display = "none";
    document.getElementById("juhoansi").style.display = "none";
    document.getElementById("other1").style.display = "none";
    document.getElementById("textEnglish").style.display = "none";
    document.getElementById("textSpanish").style.display = "none";
    document.getElementById("textFrench").style.display = "none";
    document.getElementById("textPortuguese").style.display = "none";
    document.getElementById("textSwahili").style.display = "none";
    document.getElementById("textJuhoansi").style.display = "none";

   },100)
  }

document.getElementById('infoGoBackButton').onclick = function(e){
   setTimeout(function(){
     document.getElementById("infoGoBackButton").style.display = "none";
     document.getElementById("infoCont").style.display = "none";
     document.getElementById("iconsCont").style.display = "none";
     document.getElementById("cognitoForm").style.display = "none";

     document.body.style.overflow = 'hidden';

     document.getElementById("infoButton").style.display = "none";
     document.getElementById("iconsButton").style.display = "none";
     document.getElementById('cutomiseButton').style.display = "none";
     document.getElementById("spanish").style.display = "none";
     document.getElementById("english").style.display = "none";
     document.getElementById("french").style.display = "none";
     document.getElementById("portuguese").style.display = "none";
     document.getElementById("swahili").style.display = "none";
     document.getElementById("juhoansi").style.display = "none";
     document.getElementById("other1").style.display = "none";
     document.getElementById("textEnglish").style.display = "none";
     document.getElementById("textSpanish").style.display = "none";
     document.getElementById("textFrench").style.display = "none";
     document.getElementById("textPortuguese").style.display = "none";
     document.getElementById("textSwahili").style.display = "none";
     document.getElementById("textJuhoansi").style.display = "none";

     document.getElementById('dropDown').style.backgroundColor = 'black';
     document.getElementById('imageDropDown').src = '../images/burger.png';
     document.getElementById('dropDown').style.display = "initial";
     dropDownOpen = false
     document.getElementById("youtube").style.display = "initial";
     document.getElementById("startMapping").style.display = "initial";

   },100)
   return dropDownOpen
  }

document.getElementById('youtube').onclick = function(e){
   setTimeout(function(){
     document.getElementById("textEnglish").style.display = "initial";
     document.getElementById("infoGoBackButton").style.display = "initial";

     document.getElementById('dropDown').style.display = "none";
     document.getElementById('dropDown').style.backgroundColor = 'black';
     dropDownOpen = false
     document.getElementById("infoButton").style.display = "none";
     document.getElementById("iconsButton").style.display = "none";
      document.getElementById("youtube").style.display = "none";
      document.getElementById('cutomiseButton').style.display = "none";
      document.getElementById('startMapping').style.display = "none";



    // document.getElementById("infoButton").style.display = "none";
    // document.getElementById('cutomiseButton').style.display = "none";
    // document.getElementById("startMapping").style.display = "none";
    //
    // document.getElementById("infoGoBackButton").style.display = "initial";
    //
    // document.getElementById("youtube").style.display = "none";
    // document.getElementById("spanish").style.display = "initial";
    // document.getElementById("english").style.display = "initial";
    // document.getElementById("french").style.display = "initial";
    // document.getElementById("portuguese").style.display = "initial";
    // document.getElementById("swahili").style.display = "initial";
    // document.getElementById("juhoansi").style.display = "initial";
    // document.getElementById("other1").style.display = "initial";

   },100)
   return dropDownOpen

  }

document.getElementById('english').onclick = function(e){
   setTimeout(function(){
    document.getElementById("dropDown").style.display = "initial";
     document.getElementById("youtube").style.display = "initial";
     //document.getElementById('cutomiseButton').style.display = "initial";

    document.getElementById("spanish").style.display = "none";
    document.getElementById("english").style.display = "none";
    document.getElementById("french").style.display = "none";
    document.getElementById("portuguese").style.display = "none";
    document.getElementById("swahili").style.display = "none";
    document.getElementById("juhoansi").style.display = "none";
    document.getElementById("other1").style.display = "none";

  },100)

  }
// document.getElementById('spanish').onclick = function(e){
//    setTimeout(function(){
//      document.getElementById("textSpanish").style.display = "initial";
//
//      document.getElementById("spanish").style.display = "none";
//      document.getElementById("english").style.display = "none";
//      document.getElementById("french").style.display = "none";
//      document.getElementById("portuguese").style.display = "none";
//      document.getElementById("swahili").style.display = "none";
//      document.getElementById("juhoansi").style.display = "none";
//      document.getElementById("other1").style.display = "none";
//   },100)
// }
//
// document.getElementById('french').onclick = function(e){
//    setTimeout(function(){
//      document.getElementById("textFrench").style.display = "initial";
//
//      document.getElementById("spanish").style.display = "none";
//      document.getElementById("english").style.display = "none";
//      document.getElementById("french").style.display = "none";
//      document.getElementById("portuguese").style.display = "none";
//      document.getElementById("swahili").style.display = "none";
//      document.getElementById("juhoansi").style.display = "none";
//      document.getElementById("other1").style.display = "none";
//   },100)
//
//   }
// document.getElementById('portuguese').onclick = function(e){
//    setTimeout(function(){
//      document.getElementById("textPortuguese").style.display = "initial";
//
//      document.getElementById("spanish").style.display = "none";
//      document.getElementById("english").style.display = "none";
//      document.getElementById("french").style.display = "none";
//      document.getElementById("portuguese").style.display = "none";
//      document.getElementById("swahili").style.display = "none";
//      document.getElementById("juhoansi").style.display = "none";
//      document.getElementById("other1").style.display = "none";
//   },100)
// }
//
// document.getElementById('swahili').onclick = function(e){
//    setTimeout(function(){
//      document.getElementById("textSwahili").style.display = "initial";
//
//      document.getElementById("spanish").style.display = "none";
//      document.getElementById("english").style.display = "none";
//      document.getElementById("french").style.display = "none";
//      document.getElementById("portuguese").style.display = "none";
//      document.getElementById("swahili").style.display = "none";
//      document.getElementById("juhoansi").style.display = "none";
//      document.getElementById("other1").style.display = "none";
//   },100)
//
//   }
// document.getElementById('juhoansi').onclick = function(e){
//    setTimeout(function(){
//      document.getElementById("textJuhoansi").style.display = "initial";
//
//      document.getElementById("spanish").style.display = "none";
//      document.getElementById("english").style.display = "none";
//      document.getElementById("french").style.display = "none";
//      document.getElementById("portuguese").style.display = "none";
//      document.getElementById("swahili").style.display = "none";
//      document.getElementById("juhoansi").style.display = "none";
//      document.getElementById("other1").style.display = "none";
//   },100)
// }
