<?php

//for process.php file

$hostname = '167.71.129.243';
$username = 'marcosmxv';
$password = 'ulanduse';
$database = 'lumblu';

$planetKey = "2b11aafd06e2464a85d2e97c5a176a9a";
$sentinelKey = "064f130d-c591-45b7-a80d-397152d6e995";
$firebaseKey = "AIzaSyDt3_yMQ5Zu_MhqlRzssZ_931YEBzMsIMk";

// $_POST['planetKey'] = "2b11aafd06e2464a85d2e97c5a176a9a";
// $_POST['sentinelKey'] = "064f130d-c591-45b7-a80d-397152d6e995";
// $_POST['firebaseKey'] = "AIzaSyDt3_yMQ5Zu_MhqlRzssZ_931YEBzMsIMk";


?>

<?php echo $planetKey; ?>,
<?php echo $sentinelKey; ?>,
<?php echo $firebaseKey; ?>,
