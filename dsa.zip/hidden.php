<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//for process.php file
echo 'opened';
$hostname = '167.71.129.243';
$username = 'marcosmxv';
$password = 'ulanduse';
$database = 'lumblu';

$planetKey = "2b11aafd06e2464a85d2e97c5a176a9a";
$sentinelKey = "064f130d-c591-45b7-a80d-397152d6e995";
$firebaseKey = "AIzaSyDt3_yMQ5Zu_MhqlRzssZ_931YEBzMsIMk";
// $planetKey = $_POST["2b11aafd06e2464a85d2e97c5a176a9a"];
// $sentinelKey = $_POST["064f130d-c591-45b7-a80d-397152d6e995"];
// $firebaseKey = $_POST["AIzaSyDt3_yMQ5Zu_MhqlRzssZ_931YEBzMsIMk"];



?>
<script type="text/javascript">
    var planetKey = <?php echo $planetKey; ?>;
    var sentinelKey = <?php echo $sentinelKey; ?>;
    var firebaseKey = <?php echo $firebaseKey; ?>;
</script>
