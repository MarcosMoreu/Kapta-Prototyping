var planetKey = "2b11aafd06e2464a85d2e97c5a176a9a";
var sentinelKey = "064f130d-c591-45b7-a80d-397152d6e995";
var firebaseKey = "AIzaSyDt3_yMQ5Zu_MhqlRzssZ_931YEBzMsIMk";
